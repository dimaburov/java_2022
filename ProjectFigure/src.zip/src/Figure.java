

public interface Figure {
    double perimeter();
    double square();
}
